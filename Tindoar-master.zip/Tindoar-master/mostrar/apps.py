from django.apps import AppConfig


class MostrarConfig(AppConfig):
    name = 'mostrar'
